<?php

namespace Facade\Ignition\Exceptions;

use Exception;

class UnableToShareErrorException extends Exception
{
}
